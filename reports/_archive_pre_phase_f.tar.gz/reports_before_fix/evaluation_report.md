# Agentic Pattern Evaluation Report

**Generated:** 2026-03-12 13:17:36
**Patterns Evaluated:** ReAct, ReAct_Enhanced, CoT, Reflex, ToT

## Summary Comparison

| Pattern | Strict | Lenient | Gap | Avg Latency (s) | Avg Tokens | Degradation (%) | Controllability |
|---------|--------|---------|-----|-----------------|------------|-----------------|-----------------|
| ReAct        |  43.8% |   50.0% | 6.2% |            9.60 |       2318 |            71.4 |           56.2% |
| ReAct_Enhanced |  37.5% |   37.5% | 0.0% |            7.12 |       3340 |            16.7 |           54.2% |
| CoT          |  62.5% |   62.5% | 0.0% |           14.43 |       1272 |            20.0 |           66.7% |
| Reflex       |  43.8% |   50.0% | 6.2% |           12.83 |         41 |            57.1 |           60.4% |
| ToT          |  25.0% |   25.0% | 0.0% |          129.52 |        338 |           100.0 |           84.7% |

## 1. Success Dimension

**Best Pattern:** CoT (62.5%)

### Success Rates by Pattern
- **ReAct**: 43.8%
- **ReAct_Enhanced**: 37.5%
- **CoT**: 62.5%
- **Reflex**: 43.8%
- **ToT**: 25.0%

#### ReAct - By Category
  - baseline: 50.0%
  - planning: 50.0%
  - tool: 25.0%
  - reasoning: 50.0%

#### ReAct_Enhanced - By Category
  - baseline: 75.0%
  - planning: 25.0%
  - tool: 0.0%
  - reasoning: 50.0%

#### CoT - By Category
  - baseline: 100.0%
  - planning: 50.0%
  - tool: 25.0%
  - reasoning: 75.0%

#### Reflex - By Category
  - baseline: 50.0%
  - planning: 50.0%
  - tool: 25.0%
  - reasoning: 50.0%

#### ToT - By Category
  - baseline: 50.0%
  - planning: 0.0%
  - tool: 0.0%
  - reasoning: 50.0%

## 2. Efficiency Dimension

**Fastest Pattern:** ReAct_Enhanced (7.12s)
**Slowest Pattern:** ToT (129.52s)

### Average Latency by Pattern
- **ReAct**: 9.60s
- **ReAct_Enhanced**: 7.12s
- **CoT**: 14.43s
- **Reflex**: 12.83s
- **ToT**: 129.52s

#### ReAct - Detailed Efficiency
  - Median Latency: 9.44s
  - Token Usage: 2318 avg
  - Avg Steps: 3.9

#### ReAct_Enhanced - Detailed Efficiency
  - Median Latency: 7.78s
  - Token Usage: 3340 avg
  - Avg Steps: 4.1

#### CoT - Detailed Efficiency
  - Median Latency: 11.46s
  - Token Usage: 1272 avg
  - Avg Steps: 4.0

#### Reflex - Detailed Efficiency
  - Median Latency: 12.02s
  - Token Usage: 41 avg
  - Avg Steps: 3.0

#### ToT - Detailed Efficiency
  - Median Latency: 124.87s
  - Token Usage: 338 avg
  - Avg Steps: 8.0

## 3. Robustness Dimension

**Most Robust:** ReAct_Enhanced (16.7% degradation)
**Least Robust:** ToT (100.0% degradation)

### Performance Degradation by Pattern
- **ReAct**: 71.4%
- **ReAct_Enhanced**: 16.7%
- **CoT**: 20.0%
- **Reflex**: 57.1%
- **ToT**: 100.0%

## 4. Controllability Dimension

**Most Controllable:** ToT (84.7%)

### Controllability Scores by Pattern
- **ReAct**: 56.2%
- **ReAct_Enhanced**: 54.2%
- **CoT**: 66.7%
- **Reflex**: 60.4%
- **ToT**: 84.7%

#### ReAct - Detailed Controllability
  - Schema Compliance: 25.0%
  - Tool Policy Compliance: 100.0%
  - Format Compliance: 43.8%

#### ReAct_Enhanced - Detailed Controllability
  - Schema Compliance: 25.0%
  - Tool Policy Compliance: 100.0%
  - Format Compliance: 37.5%

#### CoT - Detailed Controllability
  - Schema Compliance: 37.5%
  - Tool Policy Compliance: 100.0%
  - Format Compliance: 62.5%

#### Reflex - Detailed Controllability
  - Schema Compliance: 37.5%
  - Tool Policy Compliance: 100.0%
  - Format Compliance: 43.8%

#### ToT - Detailed Controllability
  - Schema Compliance: 87.5%
  - Tool Policy Compliance: 100.0%
  - Format Compliance: 66.7%

## 5. Recommendations

### Scenario-Based Pattern Selection

- **Complex Reasoning Tasks:** CoT (highest success rate)
- **Real-time/Low-latency Scenarios:** ReAct_Enhanced (fastest response)
- **Noisy/Unreliable Environments:** ReAct_Enhanced (most robust)
- **Enterprise/Compliance-critical:** ToT (most controllable)
